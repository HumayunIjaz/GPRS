<div class="eltd-social-sidebar-holder" >
			    <span class="eltd-icon-shortcode eltd-normal" data-hover-color="#262626" data-color="#262626">
                    <a href="https://www.facebook.com/Adnanbaigart/">
                   <img class="social-links" src="{{asset('public/upload/facebook-header.png')}}" >
                   </a>
           		 </span>
           		 <br>
    			<span class="eltd-icon-shortcode eltd-normal"  data-hover-color="#262626" data-color="#262626">
                    <a href="https://www.instagram.com/adnanbaigart/" >
                    <img class="social-links" src="{{asset('public/upload/instagram-header.png')}}" >
                   </a>
            	</span>
            	<br>
          
</div>