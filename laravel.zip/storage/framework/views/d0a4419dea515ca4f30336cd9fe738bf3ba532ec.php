<meta name="keywords" content="Adnanbaigart, Abstract, Abstratart, Design, Artanddesign, Artmetterials, Fusion, Artfusion, Calligraphy, Abstractpaintings, Paintings, Bigcanvas, Calligraphyart, Calligraphyandpainting, Strokes, Calligraphystrokes, Paintingstrokes, Artdetail, Ballanceart, Canvasballance, Colors, Colorsballance, Pakistanart, Pakistaniartist, Colorsandmetterials, Multartmetterials, Acrylicpaintings, Colorfulart, Neonpaintings, Neonart, Florocentart, Classicandmoderenart, Moderenart, Outofthebox, Arttoday, Contemporary art, Asianart, Abstractcalligraphy, Arte, Islamicart, Geometricabstract">


<link rel='dns-prefetch' href='http://maps.googleapis.com/' />

    <link rel='dns-prefetch' href='http://fonts.googleapis.com/' />
   
    <link rel='stylesheet' id='bjorn_elated_modules-css'  href="<?php echo e(asset('public/css/modules.mina288.css')); ?>" type='text/css' media='all' />
   
    <link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:700" rel="stylesheet">
   
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   
    <link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:700" rel="stylesheet">
   
    <link rel='stylesheet' id='js_composer_front-css'  href="<?php echo e(asset('public/css/js_composer.min7752.css')); ?>" type='text/css' media='all' />
   
    <link rel="icon" href="<?php echo e(asset('public/upload/cropped-fav-gradient-150x150.png')); ?>" sizes="32x32" />
   
    <link rel="icon" href="<?php echo e(asset('public/upload/cropped-fav-gradient-300x300.png')); ?>" sizes="192x192" />
    
    <link rel="apple-touch-icon-precomposed" href="<?php echo e(asset('public/upload/cropped-fav-gradient-300x300.png')); ?>" />
    
    <link rel='stylesheet' id='bjorn_elated_google_fonts-css'  href='http://fonts.googleapis.com/css?family=Montserrat%3A300%2C400%2C500%2C600%2C700%2C800&amp;subset=latin-ext&amp;ver=1.0.0' type='text/css' media='all' />

    <link rel='stylesheet' id='bjorn_elated_modules-css'  href="<?php echo e(asset('public/css/modules.mina288.css')); ?>" type='text/css' media='all' />

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script type='text/javascript' src="<?php echo e(asset('public/js/jqueryb8ff.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/jquery-1.8.3.min.js')); ?>"></script>
  <script src="<?php echo e(asset('public/js/jquery.elevatezoom.js')); ?>"></script>

<link rel="stylesheet" href="<?php echo e(asset('public/css/remodal.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/css/remodal-default-theme.css')); ?>">
<script src="<?php echo e(asset('public/js/remodal.js')); ?>"></script>


<style>

 .footerdiv{
    background-color: black;
    height: 220px;
    color: #7C7C7C;

}

.glyphicon-remove{
font-size:25px;
}
header{
   margin-top: 5%; margin-bottom: 2%;
}
#map {
        height: 400px;
        width: 100%;
       }

.parent{
    position: relative;
    
}

.absolute2 {
    position: absolute;
    width: 80%;
    right: 20px;
    bottom: 10px;
} 
.padding0{
    padding: 5px;
    margin: 5px; 
}

.padding00{
  padding-left: 0px;
}

.example {
    padding: 20px;
    color: white;
}

.detail{
font-size: 22px;
}

.size{
  font-size: 16px;
  color: blue;
}

.social-links{
  margin-top: 10px;
  height: 20px;
  width: 20px;
}

.footerhead{
  color: #FFFFFF; 
  font-size: 32px;
}

.glyphicon{
  font-size: 20px;
 color: black;  
}

.font12{
  font-size: 12px;
}

.font18{
  font-size: 18px;
}

.email{
  color: #ffffff; 
  font-size: 20px;
  font-weight: 500;
  font-style: normal;
}

.footerlinks{
  margin-right: 10px;  
  border-radius: 7px;
  height: 25px;
  width: 25px;
}

.paddingtop10{
  padding-top: 8%;
}
.eltd-social-sidebar-holder{
  left: 15px;
}
.menu{
  display: table;
  position: absolute;
  height: 70%;
  padding: 0px;
  margin: 0px;
}
.menu_iner{
  display: table-cell;
  vertical-align: middle;
  width: 340px;
  text-align: center;
}
.blog-title{
  font-size: 22px; 
  margin-top: 8%;
  line-height: 1.2em;
}
.pop-blog-title{
  font-size: 14px; 
  line-height: 1.2em ;
  padding: 0px;  
  padding-top: 20px;
}
.index_img_mob{
  display: none;
}
.index_img{
  box-shadow: 0 8px 8px 0 rgba(0, 0, 0, 0.4), 0 6px 10px 0 rgba(0, 0, 0, .4);
  padding: 0px; 
}
.mar-bottom20{
  margin-bottom: 20px;
}
.pop-title{
  padding-bottom: 10px;
  text-align: center;
  
}

.blog-date{
  font-size: 12px;
  margin: 10px 0px;
}




/* Small devices (portrait tablets and large phones, 991 and down) */
@media  screen and (max-width: 991px) and (min-width: 0px){
      .social-links{
        
        height: 40px;
        width: 40px;
      }
      .glyphicon{
        font-size: 30px;
        color: black;  
      }
      .footerlinks{
         margin-right: 15px;  
         border-radius: 7px;
         height: 40px;
         width: 40px;
      }
      .font18{
        font-size: 38px;
        font-weight: 500;
        line-height: 1.5em;
      }
      .paddingtop10{
        padding-top: 5%;
      }
      .index_img{
      display: none;
      }
      .index_img_mob{
      display: block;
       box-shadow: 0 8px 8px 0 rgba(0, 0, 0, 0.4), 0 6px 20px 0 rgba(0, 0, 0, .4);
      }
    
}

</style>