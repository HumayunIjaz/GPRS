<section  class="eltd-side-menu ">
	
	<div class="eltd-close-side-menu-holder ">
		<a class="eltd-close-side-menu" href="index.html" target="_self">
			<span  class="glyphicon glyphicon-remove"></span>
		</a>
	</div>
	<div id="text-9" class="widget eltd-sidearea widget_text" >	
			
		</div>

<div class="  menu">
		<div class="menu_iner">
		<div class="widget eltd-sidearea widget_nav_menu ">
				<ul >
					<li><a href="<?php echo e(asset('/')); ?>"><span class="font18"> Home </span></a></li>
					<li><a href="<?php echo e(asset('gallery')); ?>" ><span class="font18"> Gallery </span></a></li>
					<li><a href="<?php echo e(asset('bio')); ?>" ><span class="font18">Bio</span></a></li>
					<li><a href="<?php echo e(asset('contact')); ?>" ><span class="font18">Contact</span></a></li>
					<li><a href="<?php echo e(asset('blog')); ?>" ><span class="font18">Blog</span></a></li>
				</ul>
		</div>
		</div>               
	      </div> 
		<div class="absolute2" >
					<h3>Subscribe</h3>
					<form  method="post" >
							<div class="eltd-custom-form1">
								<div class="eltd-custom-form1-text">
										<input type="email" name="your-email"  placeholder="Email" />
    							</div>
								<div class="eltd-custom-form1-button">
										<input type="submit" value="Go" class="wpcf7-form-control wpcf7-submit" />
    							</div>
							</div>
					</form>
		</div>
	         
</section>

<header>
		<div class="row">
			<div class="col-xs-offset-1 col-md-9 col-xs-8">						
   			 	<a href="index.php">
       				<img   src="<?php echo e(asset('public/upload/adnan-shb.png')); ?>" width="270px"  alt="adnanbayg.com"/>
        		</a>			
			</div>
			<div class="col-xs-2 col-md-1">
				<div class="row" >
					<div class="col-xs-offset-7 col-xs-2" style="margin-top: 10%;  ">   
						<a class="eltd-side-menu-button-opener eltd-icon-has-hover"  href="javascript:void(0)" >
                			<span class="glyphicon glyphicon-align-right"></span>
        				</a>
					</div>
				</div>
			</div>
		</div>		
</header>