<!DOCTYPE html>
<html lang="en-US">
<head>
		<title> &#8211; ADNAN BAYG</title>

  <?php echo $__env->make('include.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
  <link href="<?php echo e(asset('public/css/style.css')); ?>" rel="stylessheet">

</head>



<body style="font-family: 'Open Sans Condensed', sans-serif;" class="eltd-side-menu-slide-from-right" >
	<div class="container-fluid">

	<?php echo $__env->make('include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<?php echo $__env->make('include.social_links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	
	<div class="row">
	   <div class="col-xs-offset-1 col-xs-10 " >
                     
          <img id="img" class="col-md-offset-0 col-md-12" src="<?php echo e(asset('public/upload/'.($row->name).'/painting.jpg')); ?>" />
                      
      </div>
	</div>
   <script type="text/javascript">
      $(document).ready(function(){
        $("#img").elevateZoom({zoomType : "lens" , lensShape : "square" , lensSize : 200 });

      //$("#img").elevateZoom({});
      });
    </script>
    <div style="margin-top: 100px"></div>
	<?php echo $__env->make('include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>

</body>
</html>