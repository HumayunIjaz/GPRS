
            
			<a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
				<i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
			</a>
            
            <!-- basic scripts -->

		<!--[if !IE]> -->
		<script src="{{asset('public/assets/js/jquery-2.1.4.min.js')}}">
			$('#value1').change(function(){
			var a = $(this).val();
			$('#img1').val(a);
			});
		</script>

		<!-- <![endif]-->

		<!--[if IE]>
<script src="assets/js/jquery-1.11.3.min.js"></script>
<![endif]-->
		<script type="text/javascript">
			if('ontouchstart' in document.documentElement) document.write("<script src='{{asset('public/assets/js/jquery.mobile.custom.min.js')}}'>"+"<"+"/script>");
		</script>
		<script src="{{asset('public/assets/js/bootstrap.min.js')}}"></script>

		<!-- page specific plugin scripts -->

		<!--[if lte IE 8]>
		  <script src="assets/js/excanvas.min.js"></script>
		<![endif]-->
		<script src="{{asset('public/assets/js/jquery-ui.custom.min.js')}}"></script>
		<script src="{{asset('public/assets/js/jquery.ui.touch-punch.min.js')}}"></script>
		<script src="{{asset('public/assets/js/chosen.jquery.min.js')}}"></script>
		<script src="{{asset('public/assets/js/spinbox.min.js')}}"></script>
		<script src="{{asset('public/assets/js/jquery.js')}}"></script>
		<script src="{{asset('public/assets/js/bootstrap-datepicker.min.js')}}"></script>
		<script src="{{asset('public/assets/js/bootstrap-timepicker.min.js')}}"></script>
		<script src="{{asset('public/assets/js/moment.min.js')}}"></script>
		<script src="{{asset('public/assets/js/daterangepicker.min.js')}}"></script>
		<script src="{{asset('public/assets/js/bootstrap-datetimepicker.min.js')}}"></script>
		<script src="{{asset('public/assets/js/bootstrap-colorpicker.min.js')}}"></script>
		<script src="{{asset('public/assets/js/jquery.knob.min.js')}}"></script>
		<script src="{{asset('public/assets/js/autosize.min.js')}}"></script>
		<script src="{{asset('public/assets/js/jquery.inputlimiter.min.js')}}"></script>
		<script src="{{asset('public/assets/js/jquery.maskedinput.min.js')}}"></script>
		<script src="{{asset('public/assets/js/bootstrap-tag.min.js')}}"></script>

		<!-- ace scripts -->
		<script src="{{asset('public/assets/js/ace-elements.min.js')}}"></script>
		<script src="{{asset('public/assets/js/ace.min.js')}}"></script>