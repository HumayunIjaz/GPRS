<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta charset="utf-8" />
<title>manage Blogs</title>
<meta name="description
" content="Common form elements and layouts" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
</head>


<!-- Load local jQuery -->




  
<body class="no-skin">
<?php echo $__env->make('include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="main-container ace-save-state" id="main-container">
<script type="text/javascript">
try{ace.settings.loadState('main-container')}catch(e){}
</script>

<div id="sidebar" class="sidebar responsive ace-save-state">
<script type="text/javascript">
try{ace.settings.loadState('sidebar')}catch(e){}
</script>
<?php echo $__env->make('include.left-bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> <!-- /.nav-list -->
</div>

<div class="main-content">
<div class="main-content-inner">



<div class="page-content">
<!-- /.ace-settings-container -->
<div class="page-header">
<h1>Manage--Blogs</h1>
</div><!-- /.page-header -->
<div class="row">
<div class="col-xs-12">
<!-- PAGE CONTENT BEGINS -->
<div class="table-responsive">
<table class="table table-bordered" >
<thead>
<tr>
<th>#</th>
<th>title</th>
<th>meta</th>
<th>keyword</th>
<th>link</th>
<th>image</th>
<th>date</th>
<th>status</th>
<th>Edit</th>
<th>Delete</th>
</tr>
</thead>
<tbody>
	<?php $no=1; ?>
	<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<td><?php echo e($no++); ?></td>
<td><?php echo e($row->title); ?></td>
<td><?php echo e($row->meta); ?></td>
<td><?php echo e($row->keyword); ?></td>
<td><?php echo e($row->link); ?></td>
<td><?php echo e($row->image); ?></td>
<td><?php echo e($row->date); ?></td>
<td><?php echo e($row->status); ?></td>
<td>

<a class="btn btn-xs btn-info" href="<?php echo e(route('blogs.edit',$row->id)); ?>" >
<i class="ace-icon fa fa-pencil bigger-120">&nbsp;&nbsp;Edit</i></a>
</td>

<td>
	
<form action="<?php echo e(route('blogs.destroy',$row->id)); ?>" method="POST">
		<?php echo e(csrf_field()); ?>

		<input type="hidden" name="_method" value="delete">
<button type="submit" class="btn btn-xs btn-danger">
<i class="ace-icon fa fa-trash bigger-120">&nbsp;&nbsp;Delete</i></button>
</form>
</div>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</tbody>
</table>
</div>	

						

<!-- PAGE CONTENT ENDS -->
</div><!-- /.col -->
</div><!-- /.row -->
</div><!-- /.page-content -->
</div>
</div>
</div>
  <!-- /.main-content -->

<!-- /.main-container -->
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>