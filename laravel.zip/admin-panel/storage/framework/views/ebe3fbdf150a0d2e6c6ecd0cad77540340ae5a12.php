<?php $__env->startSection('content'); ?>


<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Massages</title>
	</head>
	

<body class="no-skin">
<?php echo $__env->make('include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
	<div class="main-container ace-save-state" id="main-container">
		<script type="text/javascript">
			try{ace.settings.loadState('main-container')}catch(e){}
		</script>

		<div id="sidebar" class="sidebar responsive ace-save-state">
			<script type="text/javascript">
				try{ace.settings.loadState('sidebar')}catch(e){}
			</script>

				<!-- /.sidebar-shortcuts -->

				<?php echo $__env->make('include.left-bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>; <!-- /.nav-list -->

				
		</div>

		<div class="main-content">
			<div class="main-content-inner">
				<div class="row">
					<div class="col-xs-12">
						<div class="page-content">
							<div class="page-header">
								<h1>Massages</h1>
							</div>

							<div class="table-responsive">
								<table class="table table-bordered table-striped" >
									<thead>
										<tr>
										<th>#</th>
										<th>Name</th>
										<th>Email</th>
										<th colspan="5">Massage</th>
										<th>Reply </th>
										<th>Status </th>
										</tr>
									</thead>
									<tbody>
	<tr>
		<td>1</td>
		<td>M.AHMAD</td>
		<td>ahmad@gmai.com</td>
		<td colspan="5">HOW ARE YOU?</td>
		<td><center><a href="mailto:ahmad@gmail.com"><button name="update_status" type="submit" class="btn btn-xs btn-info">
			<i class="ace-icon fa fa-pencil bigger-120"> Reply  </i></button></a></center></td>
		<td style="font-size: 22px; "><center>
			<div style='color: green' class='glyphicon glyphicon-ok'></div>
		</center></td>
	</tr>


								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>

	
		</div>	
	</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>