<ul class="nav nav-list">
<li class="active">
<a href="<?php echo e(asset('/')); ?>">
<i class="menu-icon fa fa-tachometer"></i>
<span class="menu-text"> Dashboard </span></a>
<b class="arrow"></b>
</li>


<li>
<a href="<?php echo e(route('paintings.create')); ?>">
<i class="menu-icon glyphicon glyphicon-plus"></i>
<span class="menu-text">Add painting</span></a>
<b class="arrow"></b>
</li>



<li >
<a href="<?php echo e(asset('/paintings')); ?>">
<i class="menu-icon glyphicon glyphicon-search"></i>
<span class="menu-text">Manage Painting</span></a>
<b class="arrow"></b>
</li>

<li>
<a href="<?php echo e(route('blogs.create')); ?>">
<i class="menu-icon glyphicon glyphicon-plus"></i>
<span class="menu-text">Add blog</span></a>
<b class="arrow"></b>
</li>


<li >
<a href="<?php echo e(asset('/blogs')); ?>">
<i class="menu-icon glyphicon glyphicon-search"></i>
<span class="menu-text">Manage blog</span></a>
<b class="arrow"></b>
</li>


<li>
<a href="<?php echo e(asset('massage')); ?>">
<i class="menu-icon glyphicon glyphicon-comment"></i>Massages</a>
<b class="arrow"></b>
</li>

<li>
<a href="<?php echo e(asset('password')); ?>">
<i class="menu-icon glyphicon glyphicon-lock"></i>
<span class="menu-text">Change Pass</span></a>
<b class="arrow"></b>
</li>





</ul>