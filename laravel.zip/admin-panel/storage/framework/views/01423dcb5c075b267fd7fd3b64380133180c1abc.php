		<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/bootstrap.min.css')); ?>" />

		<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/fonts.googleapis.com.css')); ?>" />
		
		<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/ace.min.css')); ?>" class="ace-main-stylesheet" id="main-ace-style" />
		
		<script src="<?php echo e(asset('public/assets/js/bootstrap.min.js')); ?>"></script>
		
		<script src="<?php echo e(asset('public/assets/libs/jquery-loader.js')); ?>"></script>
		
		<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/jquery-ui.css')); ?>">
 		
 		<script src="<?php echo e(asset('public/assets/js/jquery-ui.js')); ?>"></script>
 		
 		<script src="<?php echo e(asset('public/assets/js/jquery.js')); ?>"></script>
 		
 		<script src="<?php echo e(asset('public/assets/js/bootstrap-datepicker.min.js')); ?>"></script>




