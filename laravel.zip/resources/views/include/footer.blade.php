	
	<div class="row footerdiv "  >
	<div class="col-xs-offset-1 col-md-3 col-xs-5 " >
			<div class="paddingtop10">
					<img src="{{asset('public/upload/white_logo.png')}}" height="80px" width="150px" alt="adnanbayg.com" />
					<br>
					<span class="font12">Created by M.AHMAD<br />allrightsreserved</span>
			</div>
	</div>
	<div class="col-md-2 col-xs-6 " >
			<div class="paddingtop10">
					<h2 class="footerhead">Contact</h2>
					<p class="font12" >RCG CLOTHING STORE,<br/> KOHINOOR CITY, FAISALABAD</p>
					<p>
						<strong>
							<a href="mailto:adnanbayg@gmail.com">
								<span class="email" style="">adnanbayg@gmail.com</span>
							</a>
						</strong>
					</p>
			</div>
	</div>
	<div style="padding: 0px" class="col-xs-1 col-md-offset-0 col-md-0 footerdiv"></div>
	<div class=" col-md-2  col-xs-5 footerdiv ">
		<div class="paddingtop10">		
					<h2 class="footerhead" >Share</h2>
					<div class="paddingtop10">
						<a href="https://www.facebook.com/Adnanbaigart/" >
							<img class="footerlinks" src="{{asset('public/upload/facebook.jpg')}}">
						</a>
						<a href="https://www.instagram.com/adnanbaigart/" >
							<img class="footerlinks" src="{{asset('public/upload/instagram.png')}}" >
						</a>
						<!--
						<a href="" >
							<img  class="footerlinks" src="upload/pinterest.jpg"  >
						</a>
						<a href="" >
							<img  class="footerlinks" src="upload/behance.png" >
						</a>
						-->	
					</div>
		</div>
	</div>
	<div class="col-md-2 col-xs-6 footerdiv" >
			<div class="paddingtop10">
					<p><a href="{{asset('contact')}}"><img src="{{asset('public/upload/footer-map-1.png')}}" height="100" width="335" alt="logo" /></a></p>	
			</div>


	</div>
</div>	
<script type='text/javascript' src="{{asset('public/js/scriptsa288.js')}}"></script>
<script type='text/javascript' src="{{asset('public/js/jquery.blockUI.min44fd.js')}}"></script>
<script type='text/javascript' src="{{asset('public/js/js.cookie.min6b25.js')}}"></script>
<script type='text/javascript' src="{{asset('public/js/woocommerce.min0226.js')}}"></script>
<script type='text/javascript' src="{{asset('public/js/core.mine899.js')}}"></script>
<script type='text/javascript' src="{{asset('public/js/widget.mine899.js')}}"></script>
<script type='text/javascript' src="{{asset('public/js/tabs.mine899.js')}}"></script>
<script type='text/javascript' src="{{asset('public/js/accordion.mine899.js')}}"></script>
<script type='text/javascript'>
/* <![CDATA[ */
var mejsL10n = {"language":"en-US","strings":{"Close":"Close","Fullscreen":"Fullscreen","Turn off Fullscreen":"Turn off Fullscreen","Go Fullscreen":"Go Fullscreen","Download File":"Download File","Download Video":"Download Video","Play":"Play","Pause":"Pause","Captions\/Subtitles":"Captions\/Subtitles","None":"None","Time Slider":"Time Slider","Skip back %1 seconds":"Skip back %1 seconds","Video Player":"Video Player","Audio Player":"Audio Player","Volume Slider":"Volume Slider","Mute Toggle":"Mute Toggle","Unmute":"Unmute","Mute":"Mute","Use Up\/Down Arrow keys to increase or decrease volume.":"Use Up\/Down Arrow keys to increase or decrease volume.","Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.":"Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds."}};
var _wpmejsSettings = {"pluginPath":"\/wp-includes\/js\/mediaelement\/"};
/* ]]> */
</script>
<script type='text/javascript' src="{{asset('public/js/mediaelement-and-player.min51cd.js')}}"></script>
<script type='text/javascript' src="{{asset('public/js/jquery.appeara288.js')}}"></script>
<script type='text/javascript' src="{{asset('public/js/fluidvids.mina288.js')}}"></script>
<script type='text/javascript' src="{{asset('public/js/jquery.prettyPhoto.min7752.js')}}"></script>
<script type='text/javascript' src="{{asset('public/js/perfect-scrollbar.jquery.mina288.js')}}"></script>
<script type='text/javascript' src="{{asset('public/js/countera288.js')}}"></script>
<script type='text/javascript'>
/* <![CDATA[ */
var eltdGlobalVars = {"vars":{"eltdAddForAdminBar":0,"eltdElementAppearAmount":-100,"eltdAjaxUrl":"http:\/\/bjorn.elated-themes.com\/wp-admin\/admin-ajax.php","eltdAddingToCart":"Adding to Cart","eltdStickyHeaderHeight":0,"eltdStickyHeaderTransparencyHeight":70,"eltdTopBarHeight":0,"eltdLogoAreaHeight":0,"eltdMenuAreaHeight":100,"eltdMobileHeaderHeight":70}};
var eltdPerPageVars = {"vars":{"eltdMobileHeaderHeight":70,"eltdStickyScrollAmount":0,"eltdHeaderTransparencyHeight":100,"eltdHeaderVerticalWidth":0}};
/* ]]> */
</script>
<script type='text/javascript' src="{{asset('public/js/modules.mina288.js')}}"></script>
